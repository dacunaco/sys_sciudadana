<script type="text/javascript" src="<?= base_url()?>assets/highcharts/js/highcharts.js"></script>
<script type="text/javascript">
    $(window).load(function() {
        var chart1;
        var chart2;
        
        chart1 = new Highcharts.Chart({
            chart:{
                renderTo: 'container',
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
              text: 'Incidencias por Tipos de Incidentes'  
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        color: '#000000',
                        connectorColor: '#000000',
                        format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                    }
                }
            },
            series: <?= $percentage?>
            
            
        });
        
        chart2 = new Highcharts.Chart({
            chart:{
                renderTo: 'container2',
                type: 'column'
            },
            title: {
              text: 'Incidencias por Tipos de Incidentes'  
            },
            xAxis: {
                categories: <?= $axis_data?>
            },
            yAxis: {
                title: {
                    text: 'Cantidad de Incidencias Registradas'
                }
            },
            series: <?= $series_data?>
        });
    });
</script>
    <!-- Title area -->
    <div class="titleArea">
        <div class="wrapper">
            <div class="pageTitle">
                <h5>Gestión de Incidentes</h5>
                <span>Sistema de gestión de incidencias.</span>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    
    <div class="line"></div>
    <div class="wrapper" name="container2" id="container2"></div><br />
    <div class="wrapper" name="container" id="container"></div>
    
    
    </div>
    
    <!-- Footer line -->
   