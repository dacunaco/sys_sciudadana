<?php echo $map['js']; ?>
<div id="map" class="map"><?php echo $map['html']; ?></div>
