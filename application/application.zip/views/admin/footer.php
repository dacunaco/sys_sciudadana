 <div id="footer">
        <div class="wrapper">Todo los derechos reservados por <a href="<?= base_url()?>admin" title="">La Municipalidad Provincial de Trujillo</a></div>
    </div>

</div>

<div class="clear"></div>

</body>
</html>